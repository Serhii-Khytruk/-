# Welcome to My Spaceship
***

## Task

## Description
I created a function that treats the flight path of a rocket ship as a string 
of letters and returns the following format: "{x: X, y: Y, direction: 'DIRECT'}" X, Y 
represent the final coordinates of your ship, and direction means its final direction .

## Installation

## Usage
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
