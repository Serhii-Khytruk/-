# Welcome to Js Quest01
***

## Task

## Description
I familiarized myself with the basic html layout, tried adding certain css styles and debugging javascript
## Installation

## Usage

```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
