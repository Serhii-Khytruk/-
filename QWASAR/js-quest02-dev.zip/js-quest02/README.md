# Welcome to Js Quest02
***

## Task


## Description
I familiarized myself with variable initialization, logical blocks and operators, and dynamic content changes

## Installation


## Usage

```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
