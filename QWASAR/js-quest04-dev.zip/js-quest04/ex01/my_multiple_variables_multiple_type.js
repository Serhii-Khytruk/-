var my_name = 'Luke';
var my_comma = ',';
var my_age = '34';
console.log("Hello " + my_name + my_comma + " I'm "+ my_age + " years old.");