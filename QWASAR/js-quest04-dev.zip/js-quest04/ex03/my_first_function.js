
// Following XXXXXX will be a function that will print using console.log("my_first_function")
function my_first_function(){
    console.log("my_first_function");
}


my_first_function();