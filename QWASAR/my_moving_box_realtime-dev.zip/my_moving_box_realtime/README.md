# Welcome to My Moving Box Realtime
***

## Task
I learned how to work with GIT and DOKOD

## Description
I watched videos and theoretical materials on this task 

## Installation
No installation of this project is required

## Usage
The project works with the help of manipulations in the terminal Dukod 
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
