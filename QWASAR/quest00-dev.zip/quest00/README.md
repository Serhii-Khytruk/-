# Welcome to Quest00
***

## Task
I learned to work with the terminal, git, docode
## Description
I watched the video and theoretical exercises for this task:https://drive.google.com/file/d/1UVa8OnkAQ7nziwdJNFipqo8mkI54SPx4/view
## Installation
Installation of this task is not necessary
## Usage
The project works with the help of manipulations in the Dokod terminal

./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
