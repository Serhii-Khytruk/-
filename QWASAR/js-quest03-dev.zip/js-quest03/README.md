# Welcome to Js Quest03
***

## Task

## Description
I learned about creating functions and loops and how to combine them, as well as the input return statement.

## Installation


## Usage
```
./my_project argument1 argument2
```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
