function my_abs(param_1) {
    if (param_1<0) {
        return param_1*-1;
      }
      else {
        return param_1;
      }
};