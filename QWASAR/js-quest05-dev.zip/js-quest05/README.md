# Welcome to Js Quest05
***

## Task


## Description
I learned about math functions and their types and passing arguments to any of our terminal scripts.

## Installation


## Usage

```

```

### The Core Team


<span><i>Made at <a href='https://qwasar.io'>Qwasar SV -- Software Engineering School</a></i></span>
<span><img alt='Qwasar SV -- Software Engineering School's Logo' src='https://storage.googleapis.com/qwasar-public/qwasar-logo_50x50.png' width='20px'></span>
