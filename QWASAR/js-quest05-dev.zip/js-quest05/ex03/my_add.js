function my_add(param_1, param_2) {
      return param_1+param_2
};