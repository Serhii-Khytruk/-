process.argv.forEach(function(val, index, array){
   if(index !=0 && index !=1){
       console.log(val);
   }
});