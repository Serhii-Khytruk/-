function my_each(param_1) {
    for(var i=0; i < param_1.length; i++){
        console.log(param_1[i]);
    }
};