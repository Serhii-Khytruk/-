function my_size(param_1) {
return param_1.length;
};