function my_downcase(param_1) {
return param_1.toLowerCase();
};