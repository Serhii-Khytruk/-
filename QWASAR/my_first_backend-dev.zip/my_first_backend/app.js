const express = require('express')
const app = express()
const port = 8080
const basicAuth = require('express-basic-auth')
const songs = [
    'Autumn Leaves',
    'Available',
    'Ave Maria',
    'Azure-Te (Paris Blues)',
    'A Baby Just Like You',
    'Baby, Wont You Please Come Home?',
    'Bad, Bad Leroy Brown',	
    'Bang Bang (My Baby Shot Me Down)',
    'Baubles, Bangles and Beads',
    'The Beautiful Strangers',	
    'Be Careful, Its My Heart',
    'Before the Music Ends',	
    'Begin the Beguine',	
    'The Bells of Christmas	',
    'The Best I Ever Had',	
    'The Best is Yet to Come',	
    'The Best of Everything',
    'Cherry Pies Ought to Be You',
    'Chicago (That Toddlin Town)',
    'Christmas Dreaming'
]

app.get('/', (req, res) => {
   var random_song = songs[Math.floor(Math.random()*songs.length)]
    res.send(random_song)
})

app.get('/birth_date', (req, res) => {
     res.send('December 12, 1915')
 })

 app.get('/birth_city', (req, res) => {
     res.send('Hoboken, New Jersey, U.S.')
 })

 app.get('/wives', (req, res) => {
     res.send('Nancy Barbato, Ava Gardner, Mia Farrow, Barbara Marx')
 })

 app.get('/picture', (req, res) => {    
     res.redirect('https://en.wikipedia.org/wiki/Frank_Sinatra#/media/File:Frank_Sinatra2,_Pal_Joey.jpg')
 })

 app.get('/public', (req, res) => {
    res.send('Everybody can see this page')
})

app.use(basicAuth({
    users:{ 'admin':'admin' },
    challenge : true ,
    unauthorizedResponse: function(){return "Not authorized" }
}))

app.get('/protected', (req, res) => {
    res.send('Welcome, authenticated client')
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})